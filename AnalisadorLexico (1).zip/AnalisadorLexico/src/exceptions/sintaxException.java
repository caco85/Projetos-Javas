package exceptions;

public class sintaxException  extends RuntimeException{
	public sintaxException (String msg) {
		super(msg);
	}

}