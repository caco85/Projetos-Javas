package exceptions;

public class semanticoException extends RuntimeException {
	public semanticoException(String msg) {
		super(msg);
	}
}