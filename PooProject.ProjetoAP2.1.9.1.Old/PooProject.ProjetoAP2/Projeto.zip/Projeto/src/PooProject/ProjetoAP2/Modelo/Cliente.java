package PooProject.ProjetoAP2.Modelo;

public class Cliente {
	
	//Cliente PF
	private int codCliente;
	private String nome;
	private String CPF;
	private String email;
	private String dataNascimento;
	private String telefone;
	private Endereco endereco;
	
	
	//cliente PJ
	private int codClientePJ;
	private String razaoSocial;
	private String CNPJ;
	private String dataFundacao;
	private String nomeFantasia;
	private int inscricaoEstadual;
	private String emailPJ;
	private String telef;
	private Endereco end;
	
	
	public Cliente(int codCliente, String nome, String cPF, String email, String dataNascimento,String telefone, Endereco endereco) {
		super();
		this.codCliente = codCliente;
		this.nome = nome;
		this.CPF = cPF;
		this.email = email;
		this.dataNascimento = dataNascimento;
		this.telefone = telefone;
		this.endereco = endereco;
	}

	public Cliente() {
		super();
	}

	public Cliente(int codClientePJ, String razaoSocial, String cNPJ, String dataFundacao, String nomeFantasia,
			int inscricaoEstadual,String emailPj,String telef ,Endereco end) {
		super();
		this.codClientePJ = codClientePJ;
		this.razaoSocial = razaoSocial;
		this.CNPJ = cNPJ;
		this.dataFundacao = dataFundacao;
		this.nomeFantasia = nomeFantasia;
		this.inscricaoEstadual = inscricaoEstadual;
		this.emailPJ = emailPj;
		this.telef = telef ;
		this.end = end;
	}

	public int getCodCliente() {
		return codCliente;
	}

	public void setCodCliente(int codCliente) {
		this.codCliente = codCliente;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCPF() {
		return CPF;
	}

	public void setCPF(String cPF) {
		this.CPF = cPF;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	
	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	
	//clientePJ

	public int getCodClientePJ() {
		return codClientePJ;
	}

	public void setCodClientePJ(int codClientePJ) {
		this.codClientePJ = codClientePJ;
	}

	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public String getCNPJ() {
		return CNPJ;
	}

	public void setCNPJ(String cNPJ) {
		this.CNPJ = cNPJ;
	}

	public String getDataFundacao() {
		return dataFundacao;
	}

	public void setDataFundacao(String dataFundacao) {
		this.dataFundacao = dataFundacao;
	}

	public String getNomeFantasia() {
		return nomeFantasia;
	}

	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

	public int getInscricaoEstadual() {
		return inscricaoEstadual;
	}

	public void setInscricaoEstadual(int inscricaoEstadual) {
		this.inscricaoEstadual = inscricaoEstadual;
	}
	
	

	public String getEmailPJ() {
		return emailPJ;
	}

	public void setEmailPJ(String emailPJ) {
		this.emailPJ = emailPJ;
	}

	public String getTelef() {
		return telef;
	}

	public void setTelef(String telef) {
		this.telef = telef;
	}

	public Endereco getEnd() {
		return end;
	}

	public void setEnd(Endereco end) {
		this.end = end;
	}

	@Override
	public String toString() {
		return "Cliente [codCliente=" + codCliente + ", nome=" + nome + ", CPF=" + CPF + ", email=" + email
				+ ", dataNascimento=" + dataNascimento + ", telefone=" + telefone + ", endereco=" + endereco
				+ ", codClientePJ=" + codClientePJ + ", razaoSocial=" + razaoSocial + ", CNPJ=" + CNPJ
				+ ", dataFundacao=" + dataFundacao + ", nomeFantasia=" + nomeFantasia + ", inscricaoEstadual="
				+ inscricaoEstadual + ", emailPJ=" + emailPJ + ", telef=" + telef + ", end=" + end + "]";
	}

	
}
