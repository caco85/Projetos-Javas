package PooProject.ProjetoAP2.Controlador;

import PooProject.ProjetoAP2.Excecao.ClienteException;
import PooProject.ProjetoAP2.Excecao.RepositorioClienteException;
import PooProject.ProjetoAP2.Modelo.Cliente;
import PooProject.ProjetoAP2.Repositorio.RepositorioCliente;

public class ControladorCliente implements IControladorCliente {
	
	private static ControladorCliente instancia;
	private RepositorioCliente repCliente;
	
	public static ControladorCliente getInstance() {
		if (instancia == null){
			instancia = new ControladorCliente();
		}
		return instancia;
	}

	@Override
	public void inserirCliente(Cliente cliente) throws ClienteException, RepositorioClienteException {
		this.repCliente.inserirCliente(cliente);
	}

	@Override
	public void excluirCliente(Cliente cliente) throws ClienteException, RepositorioClienteException {
		this.repCliente.excluirCliente(cliente);
	}

	@Override
	public void excluirClientePeloNome(String nome) throws ClienteException, RepositorioClienteException {
		this.repCliente.excluirClientePeloNome(nome);
	}

	@Override
	public Cliente pesquisarClientePeloCPF(String cpf) throws ClienteException, RepositorioClienteException {
		return repCliente.pesquisarClientePeloCPF(cpf);
	}

	@Override
	public Cliente pesquisarClientePeloNome(String nome) throws ClienteException, RepositorioClienteException {
		return repCliente.pesquisarClientePeloNome(nome);
	}

	@Override
	public Cliente[] pesquisarClientePeloBairro(String bairro) throws ClienteException, RepositorioClienteException {
		return repCliente.pesquisarClientePeloBairro(bairro);
	}

	@Override
	public void inserirClientePJ(Cliente cliente) throws ClienteException, RepositorioClienteException {
		this.repCliente.inserirClientePJ(cliente);
	}

	@Override
	public Cliente pesquisarClientePeloCNPJ(String cnpj) throws ClienteException, RepositorioClienteException {
		return repCliente.pesquisarClientePeloCNPJ(cnpj);
	}

}
