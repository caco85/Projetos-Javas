package PooProject.ProjetoAP2.Excecao;

public class ProdutoException  extends Exception{
	 public ProdutoException(String textoExcecao){
		 super(textoExcecao);
	 }

}
