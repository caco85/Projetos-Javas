package PooProject.ProjetoAP2.Excecao;

public class EmpresaException extends Exception{
	 public EmpresaException(String textoExcecao){
		 super(textoExcecao);
	 }

}
