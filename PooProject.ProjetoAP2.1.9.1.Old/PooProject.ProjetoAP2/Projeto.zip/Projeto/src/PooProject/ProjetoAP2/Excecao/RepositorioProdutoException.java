package PooProject.ProjetoAP2.Excecao;

public class RepositorioProdutoException extends Exception{
	 public RepositorioProdutoException(String textoExcecao){
		 super(textoExcecao);
	 }

}
