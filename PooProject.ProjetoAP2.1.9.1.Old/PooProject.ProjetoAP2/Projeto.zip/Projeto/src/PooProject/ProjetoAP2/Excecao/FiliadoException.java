package PooProject.ProjetoAP2.Excecao;

public class FiliadoException extends Exception{
	 public FiliadoException(String textoExcecao){
		 super(textoExcecao);
	 }
}
