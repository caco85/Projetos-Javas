package PooProject.ProjetoAP2.Excecao;

public class RepositorioFiliadoException extends Exception{
	 public RepositorioFiliadoException(String textoExcecao){
		 super(textoExcecao);
	 }
}
