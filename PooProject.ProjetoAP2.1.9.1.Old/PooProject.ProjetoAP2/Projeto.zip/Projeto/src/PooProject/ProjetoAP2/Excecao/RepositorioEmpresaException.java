package PooProject.ProjetoAP2.Excecao;

public class RepositorioEmpresaException extends Exception{
	 public RepositorioEmpresaException(String textoExcecao){
		 super(textoExcecao);
	 }

}
