package PooProject.ProjetoAP2.Excecao;

public class RepositorioVendaException extends Exception{
	 public RepositorioVendaException(String textoExcecao){
		 super(textoExcecao);
	 }
}