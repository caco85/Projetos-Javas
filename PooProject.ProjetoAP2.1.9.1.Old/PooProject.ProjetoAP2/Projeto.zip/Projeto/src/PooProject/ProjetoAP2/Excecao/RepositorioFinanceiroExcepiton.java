package PooProject.ProjetoAP2.Excecao;

public class RepositorioFinanceiroExcepiton extends Exception{
	 public RepositorioFinanceiroExcepiton(String textoExcecao){
		 super(textoExcecao);
	 }
}
