package PooProject.ProjetoAP2.Excecao;

public class RepositorioClienteException extends Exception{
	 public RepositorioClienteException(String textoExcecao){
		 super(textoExcecao);
	 }
}
