package PooProject.ProjetoAP2.Excecao;

public class RepositorioFuncionarioException extends Exception{
	 public RepositorioFuncionarioException(String textoExcecao){
		 super(textoExcecao);
	 }
}
