package PooProject.ProjetoAP2.Excecao;

public class VendaException extends Exception{
	 public VendaException(String textoExcecao){
		 super(textoExcecao);
	 }
}
