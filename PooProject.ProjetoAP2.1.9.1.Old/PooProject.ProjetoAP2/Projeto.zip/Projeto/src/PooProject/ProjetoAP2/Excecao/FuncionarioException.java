package PooProject.ProjetoAP2.Excecao;

public class FuncionarioException extends Exception{
	 public FuncionarioException(String textoExcecao){
		 super(textoExcecao);
	 }
}
