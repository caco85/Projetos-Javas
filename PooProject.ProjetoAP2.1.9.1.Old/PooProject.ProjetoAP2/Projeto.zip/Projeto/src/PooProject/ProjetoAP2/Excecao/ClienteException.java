package PooProject.ProjetoAP2.Excecao;

public class ClienteException 	extends Exception{
		 public ClienteException(String textoExcecao){
			 super(textoExcecao);
		 }
}
