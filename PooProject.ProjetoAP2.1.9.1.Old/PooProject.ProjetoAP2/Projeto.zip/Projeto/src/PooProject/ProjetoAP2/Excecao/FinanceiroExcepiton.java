package PooProject.ProjetoAP2.Excecao;

public class FinanceiroExcepiton extends Exception{
	 public FinanceiroExcepiton(String textoExcecao){
		 super(textoExcecao);
	 }
}
