package PooProject.ProjetoAP2.Repositorio;

import PooProject.ProjetoAP2.Excecao.ProdutoException;
import PooProject.ProjetoAP2.Excecao.RepositorioClienteException;
import PooProject.ProjetoAP2.Excecao.RepositorioProdutoException;
import PooProject.ProjetoAP2.Modelo.Produto;

public class RepositorioProduto implements IRepositorioProduto {
	private static Produto [] listaProduto;
	private static RepositorioProduto instancia;
	
	public static RepositorioProduto getInstance(){
		if (instancia == null) {
			instancia = new RepositorioProduto();	
		}
		return instancia;
	}
	
	public  RepositorioProduto() {
		if (listaProduto == null) {
			listaProduto = new Produto[1000];
			
		}
	}
	
	@Override
	public void inserirProduto(Produto produto) throws ProdutoException, RepositorioProdutoException {
		
	}

	@Override
	public void excluirProduto(Produto produto) throws ProdutoException, RepositorioProdutoException {
		for (int i = 0; i < listaProduto.length; i++) {
			if (listaProduto != null) {
				listaProduto[i] = null;
			}else {
				throw new RepositorioProdutoException("Produto n�o localizado");
			}
		}
	}

	@Override
	public void excluirProdutoPeloNome(String nome) throws ProdutoException, RepositorioProdutoException {
		for (int i = 0; i < listaProduto.length; i++) {
			if (listaProduto[i] != null && listaProduto[i].getNomeProduto().equals(nome)) {
				listaProduto[i] = null;
			}else{
				throw new RepositorioProdutoException("Produto n�o localizado");
			}
		}
	}

	@Override
	public Produto pesquisarProdutoPeloCodigo(int codigo) throws ProdutoException, RepositorioProdutoException {
		for (int i = 0; i < listaProduto.length; i++) {
			if (listaProduto[i] != null && listaProduto[i].getCodProduto() == codigo) {
				return listaProduto[i];
			}else{
				throw new RepositorioProdutoException("Cliente n�o localizado");
			}
		}
		return null;
	}

	@Override
	public Produto pesquisarProdutoPeloNome(String nome) throws ProdutoException, RepositorioProdutoException {

		return null;
	}

	@Override
	public Produto[] pesquisarProdutoPeloPreco(Double preco) throws ProdutoException, RepositorioProdutoException {
		return null;
	}

}
