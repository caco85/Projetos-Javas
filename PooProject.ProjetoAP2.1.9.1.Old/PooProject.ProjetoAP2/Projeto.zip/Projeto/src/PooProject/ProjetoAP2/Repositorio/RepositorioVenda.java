package PooProject.ProjetoAP2.Repositorio;

public class RepositorioVenda {

}
