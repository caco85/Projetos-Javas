package PooProject.ProjetoAP2.Repositorio;

import PooProject.ProjetoAP2.Excecao.FuncionarioException;
import PooProject.ProjetoAP2.Excecao.RepositorioFuncionarioException;
import PooProject.ProjetoAP2.Modelo.Funcionario;

public class RepositorioFuncionario implements IRepositorioFuncionario{
	
	private Funcionario [] listaFuncionario;
	private static RepositorioFuncionario instancia;
	
	public static RepositorioFuncionario getInstance(){
		if (instancia == null) {
			instancia = new RepositorioFuncionario();
			
		}
		return instancia;
	}	
	
	public  RepositorioFuncionario() {
		if (listaFuncionario == null){
			listaFuncionario = new Funcionario[1000];
		}
	}
	

	@Override
	public void inserirFuncionario(Funcionario funcionario) throws FuncionarioException, RepositorioFuncionarioException {
		String cpf = null;
		int codigo = 0;
		for (int i = 0; i < listaFuncionario.length; i++) {
			if (listaFuncionario[i] == null) {
				listaFuncionario[i] = funcionario;
			}else if (listaFuncionario[i].getCpf().equals(cpf) && listaFuncionario[i].getCodFuncionario() == codigo) {
				throw new RepositorioFuncionarioException("N�o foi poss�vel cadastrar,pois ja existe Funcionario com este CPF ou Codigo ");
			}
		}
	}

	@Override
	public void excluirFuncionario(Funcionario cliente) throws FuncionarioException, RepositorioFuncionarioException {
		for (int i = 0; i < listaFuncionario.length; i++) {
			if (listaFuncionario[i] != null) {
				listaFuncionario[i] = null;
				
			}else {
				throw new RepositorioFuncionarioException("N�o foi poss�vel Excluir,pois Funcionario n�o foi localizado ");
			}
		}
	}

	@Override
	public void excluirFuncionarioPeloNome(String nome) throws FuncionarioException, RepositorioFuncionarioException {
		for (int i = 0; i < listaFuncionario.length; i++) {
			if (listaFuncionario[i] != null && listaFuncionario[i].getNomeFuncionario().equals(nome)) {
				listaFuncionario[i] = null;
				
			}else {
				throw new RepositorioFuncionarioException("N�o foi poss�vel Excluir,pois Funcionario n�o foi localizado ");
			}
		}
	}

	@Override
	public Funcionario pesquisarFuncionarioPeloCPF(String cpf)throws FuncionarioException, RepositorioFuncionarioException {
		for (int i = 0; i < listaFuncionario.length; i++) {
			if (listaFuncionario[i] != null && listaFuncionario[i].getCpf().equals(cpf)) {
				return listaFuncionario[i];
				
			} else {
				throw new RepositorioFuncionarioException("Funcionario n�o foi localizado ");
			}
		}
		return null;
	}

	@Override
	public Funcionario pesquisarFuncionarioPeloNome(String nome)throws FuncionarioException, RepositorioFuncionarioException {	
		for (int i = 0; i < listaFuncionario.length; i++) {
			if (listaFuncionario[i] != null && listaFuncionario[i].getNomeFuncionario().equals(nome)) {
				return listaFuncionario[i];
				
			} else {
				throw new RepositorioFuncionarioException("Funcionario n�o foi localizado ");
			}
		}
		return null;
	}

	@Override
	public Funcionario[] pesquisarFuncionarioPeloBairro(String bairro)throws FuncionarioException, RepositorioFuncionarioException {
		Funcionario [] funcionarios = null;
		int cont = 0;
		for (int i = 0; i < listaFuncionario.length; i++) {
			if (listaFuncionario[i] != null && listaFuncionario[i].getEnd().getBairro().equals(bairro)) {
				cont++;
			}
			
		}
		if (cont > 0) {
			funcionarios = new Funcionario[cont];
			int p = 0;
			for (int i = 0; i < listaFuncionario.length; i++) {
				if (listaFuncionario[i] != null && listaFuncionario[i].getEnd().getBairro().equals(bairro))  {
					funcionarios[p] = listaFuncionario[i];
					p++;
				}
				
			}
			return funcionarios;
		}
		
		return null;
	}

}
