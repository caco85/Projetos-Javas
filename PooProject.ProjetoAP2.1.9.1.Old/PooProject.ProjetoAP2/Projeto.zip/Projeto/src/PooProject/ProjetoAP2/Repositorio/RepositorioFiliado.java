package PooProject.ProjetoAP2.Repositorio;

import PooProject.ProjetoAP2.Excecao.FiliadoException;
import PooProject.ProjetoAP2.Excecao.RepositorioFiliadoException;
import PooProject.ProjetoAP2.Excecao.RepositorioFuncionarioException;
import PooProject.ProjetoAP2.Modelo.Filiado;
import PooProject.ProjetoAP2.Modelo.Funcionario;

public class RepositorioFiliado implements IRepositorioFiliado {
	
	
	private Filiado [] listaFiliado;
	private static RepositorioFiliado instancia;
	
	public static RepositorioFiliado getInstance(){
		if (instancia == null) {
			instancia = new RepositorioFiliado();
			
		}
		return instancia;
	}	
	
	public  RepositorioFiliado() {
		if (listaFiliado == null){
			listaFiliado = new Filiado[1000];
		}
	}

	@Override
	public void inserirFiliado(Filiado filiado) throws FiliadoException,RepositorioFiliadoException {
		
		String cnpj = null;
		int codigo = 0;
		for (int i = 0; i < listaFiliado.length; i++) {
			if (listaFiliado[i] == null) {
				listaFiliado[i] = filiado;
			}else if (listaFiliado[i].getCnpj().equals(cnpj) && listaFiliado[i].getCodFiliado() == codigo) {
				throw new RepositorioFiliadoException("N�o foi poss�vel cadastrar,pois ja existe Filiado com este CNPJ ou Codigo ");
			}
		}
		
		
	}

	@Override
	public void excluirFiliado(Filiado filiado) throws FiliadoException,RepositorioFiliadoException {
		
		for (int i = 0; i < listaFiliado.length; i++) {
			if (listaFiliado[i] != null) {
				listaFiliado[i] = null;
				
			}else {
				throw new RepositorioFiliadoException("N�o foi poss�vel Excluir,pois Filiado n�o foi localizado ");
			}
		}
		
		
	}

	@Override
	public void excluirFiliadoPeloNome(String nome) throws FiliadoException,RepositorioFiliadoException {
		
		for (int i = 0; i < listaFiliado.length; i++) {
			if (listaFiliado[i] != null && listaFiliado[i].getNomeFiliado().equals(nome)) {
				listaFiliado[i] = null;
				
			}else {
				throw new RepositorioFuncionarioException("N�o foi poss�vel Excluir,pois Filiado n�o foi localizado ");
			}
		}
		
		
	}

	@Override
	public Filiado pesquisarFiliadoPeloCNPJ(String cnpj)throws FiliadoException, RepositorioFiliadoException {
		
		for (int i = 0; i < listaFiliado.length; i++) {
			if (listaFiliado[i] != null && listaFiliado[i].getCnpj().equals(cnpj)) {
				return listaFiliado[i];
				
			} else {
				throw new RepositorioFiliadoException("Filiado n�o foi localizado ");
			}
		}
		return null;

		
	}

	@Override
	public Filiado pesquisarFiliadoPeloNome(String nome)throws FiliadoException, RepositorioFiliadoException {
	
		for (int i = 0; i < listaFiliado.length; i++) {
			if (listaFiliado[i] != null && listaFiliado[i].getNomeFiliado().equals(nome)) {
				return listaFiliado[i];
				
			} else {
				throw new RepositorioFiliadoException("Filiado n�o foi localizado ");
			}
		}
		return null;
		
	}

	//@Override
	public Filiado[] pesquisarFiliadoPeloTipoFornecimento String tipoFornecimento) throws FiliadoException,RepositorioFiliadoException {
		
		Filiado [] filiados = null;
		int cont = 0;
		for (int i = 0; i < listaFiliado.length; i++) {
			if (listaFiliado[i] != null && listaFiliado[i].getTipoFornecimento().equals(tipoFornecimento)) {
				cont++;
			}
			
		}
		if (cont > 0) {
			filiados = new Filiado[cont];
			int p = 0;
			for (int i = 0; i < listaFiliado.length; i++) {
				if (listaFiliado[i] != null && listaFiliado[i].getTipoFornecimento().equals(tipoFornecimento))  {
					filiados[p] = listaFiliado[i];
					p++;
				}
				
			}
			return filiados;
		}
		
		return null;
		
	}
	

}
