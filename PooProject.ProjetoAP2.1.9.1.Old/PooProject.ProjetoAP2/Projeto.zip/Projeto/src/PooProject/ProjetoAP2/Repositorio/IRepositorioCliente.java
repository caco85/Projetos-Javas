package PooProject.ProjetoAP2.Repositorio;

import PooProject.ProjetoAP2.Excecao.ClienteException;
import PooProject.ProjetoAP2.Excecao.RepositorioClienteException;
import PooProject.ProjetoAP2.Modelo.Cliente;

public interface IRepositorioCliente {
	public void inserirCliente(Cliente cliente) throws ClienteException,RepositorioClienteException ;
	public void excluirCliente (Cliente cliente)throws ClienteException,RepositorioClienteException;
	public void  excluirClientePeloNome(String nome)throws ClienteException,RepositorioClienteException;
	public Cliente pesquisarClientePeloCPF(String cpf)throws ClienteException,RepositorioClienteException;
	public Cliente  pesquisarClientePeloNome(String nome)throws ClienteException,RepositorioClienteException;
	public Cliente[] pesquisarClientePeloBairro(String bairro)throws ClienteException,RepositorioClienteException;
	public void inserirClientePJ(Cliente cliente)throws ClienteException,RepositorioClienteException;
	public Cliente pesquisarClientePeloCNPJ(String cnpj)throws ClienteException,RepositorioClienteException;
}
