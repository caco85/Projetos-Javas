package PooProject.ProjetoAP2.Repositorio;

import PooProject.ProjetoAP2.Excecao.ClienteException;
import PooProject.ProjetoAP2.Excecao.RepositorioClienteException;
import PooProject.ProjetoAP2.Modelo.Cliente;

public class RepositorioCliente implements IRepositorioCliente{
	private static Cliente [] listaClientes;
	private static RepositorioCliente instancia;
	
	public static RepositorioCliente getInstance(){
		if (instancia == null){
			instancia = new RepositorioCliente();
		}
		return instancia;
	}
	
	public RepositorioCliente(){
		if(listaClientes == null){
			listaClientes = new Cliente[1000];
		}
	}
	@Override
	public void inserirCliente(Cliente cliente) throws ClienteException, RepositorioClienteException {	
		String cpf = null;
		int codCliente = 0;
		for (int i = 0; i < listaClientes.length; i++) {
			if (listaClientes[i] == null){
				listaClientes[i] = cliente;
			}else if(listaClientes[i].getCPF().equals(cpf) && listaClientes[i].getCodCliente() == codCliente){
				throw new RepositorioClienteException("N�o foi poss�vel cadastrar,pois ja existe Cliente com este CPF ou Codigo ");
			} 
		}
	}

	@Override
	public void excluirCliente(Cliente cliente) throws ClienteException, RepositorioClienteException {
		for (int i = 0; i < listaClientes.length; i++) {
			if (listaClientes != null) {
				listaClientes[i] = null;
			}else {
				throw new RepositorioClienteException("Cliente n�o localizado");
			}
		}
	}

	@Override
	public void excluirClientePeloNome(String nome) throws ClienteException, RepositorioClienteException {
		for (int i = 0; i < listaClientes.length; i++) {
			if (listaClientes[i] != null && listaClientes[i].getNome().equals(nome)) {
				listaClientes[i] = null;
			}else{
				throw new RepositorioClienteException("Cliente n�o localizado");
			}
		}
	}

	@Override
	public Cliente pesquisarClientePeloCPF(String cpf) throws ClienteException, RepositorioClienteException {
		for (int i = 0; i < listaClientes.length; i++) {
			if (listaClientes[i] != null && listaClientes[i].getCPF().equals(cpf)) {
				return listaClientes[i];
			}else{
				throw new RepositorioClienteException("Cliente n�o localizado");
			}
		}
		return null;
	}

	@Override
	public Cliente pesquisarClientePeloNome(String nome) throws ClienteException, RepositorioClienteException {
		for (int i = 0; i < listaClientes.length; i++) {
			if (listaClientes[i] != null && listaClientes[i].getNome().equals(nome)) {
				return listaClientes[i];
				
			}
		}
		return null;
	}

	@Override
	public Cliente[] pesquisarClientePeloBairro(String bairro) throws ClienteException, RepositorioClienteException {
		Cliente [] clientes = null;
		int cont = 0;
		for (int i = 0; i < listaClientes.length; i++) {
			if (listaClientes[i] != null && listaClientes[i].getEndereco().getBairro().equals(bairro)) {
				cont ++;				
			}
		}
		if (cont > 0) {
			clientes = new Cliente[cont];
			int p = 0;
			for (int i = 0; i < listaClientes.length; i++) {
				if(listaClientes[i] != null && listaClientes[i].getEndereco().getBairro().equals(bairro)){
					clientes[p] = listaClientes[i];
					p++;
				}
				
			}
			return clientes;
		}
		
		return null;
	}

	@Override
	public void inserirClientePJ(Cliente cliente) throws ClienteException, RepositorioClienteException {
		String cnpj = null;
		int codCliente = 0;
		for (int i = 0; i < listaClientes.length; i++) {
			if (listaClientes[i] == null){
				listaClientes[i] = cliente;
			}else if(listaClientes[i].getCNPJ().equals(cnpj) && listaClientes[i].getCodCliente() == codCliente){
				throw new RepositorioClienteException("N�o foi poss�vel cadastrar,pois ja existe Cliente com este CPF ou Codigo ");
			} 
		}
		
	}

	@Override
	public Cliente pesquisarClientePeloCNPJ(String cnpj) throws ClienteException, RepositorioClienteException {
		for (int i = 0; i < listaClientes.length; i++) {
			if (listaClientes[i] != null && listaClientes[i].getCNPJ().equals(cnpj)) {
				return listaClientes[i];
			}else{
				throw new RepositorioClienteException("Cliente n�o localizado");
			}
		}
		return null;
	}


	
}
