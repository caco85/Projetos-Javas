package PooProject.ProjetoAP2.Fachada;

import PooProject.ProjetoAP2.Controlador.ControladorCliente;
import PooProject.ProjetoAP2.Controlador.ControladorFuncionario;
import PooProject.ProjetoAP2.Controlador.IControladorCliente;
import PooProject.ProjetoAP2.Controlador.IControladorFuncionario;
import PooProject.ProjetoAP2.Controlador.IControladorProduto;
import PooProject.ProjetoAP2.Excecao.ClienteException;
import PooProject.ProjetoAP2.Excecao.FuncionarioException;
import PooProject.ProjetoAP2.Excecao.ProdutoException;
import PooProject.ProjetoAP2.Excecao.RepositorioClienteException;
import PooProject.ProjetoAP2.Excecao.RepositorioFuncionarioException;
import PooProject.ProjetoAP2.Excecao.RepositorioProdutoException;
import PooProject.ProjetoAP2.Modelo.Cliente;
import PooProject.ProjetoAP2.Modelo.Funcionario;
import PooProject.ProjetoAP2.Modelo.Produto;

public class Fachada implements IControladorCliente,IControladorFuncionario, IControladorProduto{
	
	private static Fachada  instancia;
	private IControladorCliente controladorCliente;
	private IControladorFuncionario controladorFuncionario;
	
	public static Fachada getInstance(){
		if (instancia == null ){
			instancia = new Fachada();
		}
		return instancia;
	}
	private  Fachada() {
		controladorCliente = ControladorCliente.getInstance();
		controladorFuncionario = ControladorFuncionario.getInstance();
	}

	@Override
	public void inserirCliente(Cliente cliente) throws ClienteException, RepositorioClienteException {
		this.controladorCliente.inserirCliente(cliente);
	}

	@Override
	public void excluirCliente(Cliente cliente) throws ClienteException, RepositorioClienteException {
		this.controladorCliente.excluirCliente(cliente);
	}

	@Override
	public void excluirClientePeloNome(String nome) throws ClienteException, RepositorioClienteException {
		this.controladorCliente.excluirClientePeloNome(nome);
	}

	@Override
	public Cliente pesquisarClientePeloCPF(String cpf) throws ClienteException, RepositorioClienteException {
		return this.controladorCliente.pesquisarClientePeloCPF(cpf);
	}

	@Override
	public Cliente pesquisarClientePeloNome(String nome) throws ClienteException, RepositorioClienteException {
		return this.controladorCliente.pesquisarClientePeloNome(nome);
	}

	@Override
	public Cliente[] pesquisarClientePeloBairro(String bairro) throws ClienteException, RepositorioClienteException {
		return this.controladorCliente.pesquisarClientePeloBairro(bairro);
	}

	@Override
	public void inserirClientePJ(Cliente cliente) throws ClienteException, RepositorioClienteException {
		this.controladorCliente.inserirClientePJ(cliente);
	}

	@Override
	public Cliente pesquisarClientePeloCNPJ(String cnpj) throws ClienteException, RepositorioClienteException {
		return this.controladorCliente.pesquisarClientePeloCNPJ(cnpj);
	}
	
	/**    Funcionarios    */
	@Override
	public void inserirFuncionario(Funcionario funcionario) throws FuncionarioException, RepositorioFuncionarioException {
		this.controladorFuncionario.inserirFuncionario(funcionario);
	}
	@Override
	public void excluirFuncionario(Funcionario funcionario) throws FuncionarioException, RepositorioFuncionarioException {
		this.controladorFuncionario.excluirFuncionario(funcionario);
	}
	@Override
	public void excluirFuncionarioPeloNome(String nome) throws FuncionarioException, RepositorioFuncionarioException {
		this.controladorFuncionario.excluirFuncionarioPeloNome(nome);
	}
	@Override
	public Funcionario pesquisarFuncionarioPeloCPF(String cpf) throws FuncionarioException, RepositorioFuncionarioException {
		return this.controladorFuncionario.pesquisarFuncionarioPeloCPF(cpf);
	}
	@Override
	public Funcionario pesquisarFuncionarioPeloNome(String nome) throws FuncionarioException, RepositorioFuncionarioException {
		return controladorFuncionario.pesquisarFuncionarioPeloNome(nome);
	}
	@Override
	public Funcionario[] pesquisarFuncionarioPeloBairro(String bairro)throws FuncionarioException, RepositorioFuncionarioException {
		return controladorFuncionario.pesquisarFuncionarioPeloBairro(bairro);
	}
	
	
	/**  Produto */
	
	
	@Override
	public void inserirProduto(Produto produto) throws ProdutoException,
			RepositorioProdutoException {
	
		
	}
	@Override
	public void excluirProduto(Produto produto) throws ProdutoException,
			RepositorioProdutoException {
		
		
	}
	@Override
	public void excluirProdutoPeloNome(String nome) throws ProdutoException,
			RepositorioProdutoException {
	
		
	}
	@Override
	public Produto pesquisarProdutoPeloCodigo(int codigo)
			throws ProdutoException, RepositorioProdutoException {

		return null;
	}
	@Override
	public Produto pesquisarProdutoPeloNome(String nome)
			throws ProdutoException, RepositorioProdutoException {

		return null;
	}
	@Override
	public Produto[] pesquisarProdutoPeloPreco(Double preco)
			throws ProdutoException, RepositorioProdutoException {
		
		return null;
	}

}
