package compiladorl3;

public class ExceptionToken  extends Exception {

    public ExceptionToken(String textException) {
        super(textException);
    }
}