package List;

public class adjacente {
	int id;
	double peso;

	public adjacente(int id, double peso2) {
		this.peso = peso2;
		this.id = id;

	}

	public int getId() {
		return this.id;
	}

	public double getPeso() {
		return this.peso;
	}
}