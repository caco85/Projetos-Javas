package com.diegopinheiro.estruturadados1.list02;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;


public class TestCircularLinkedList {
	
	@Test(timeout = 5000)
    public void testEmptyTrue()
    {
        CircularLinkedList l = new CircularLinkedList();
        assertTrue(l.isEmpty());
    }
	
	@Test(timeout = 5000)
    public void testEmptyFalse()
    {
		CircularLinkedList l = new CircularLinkedList();
        l.addFirst(0);
        assertTrue(!l.isEmpty());
    }
	
	@Test(timeout = 5000)
    public void testAddFirst()
    {
		CircularLinkedList l = new CircularLinkedList();
        int[] list_expected = {1,2,3};
        for (int i: list_expected ) {
        	l.addFirst(i);
        }
        
        ListNode node = l.getTail();
        for (int expected: list_expected  ) {
        	int actual = node.getData();
        	assertEquals(expected, actual);
        	node = node.getPrevious();
        }      
    }
	
	@Test(timeout = 5000)
    public void testAddLast()
    {
		CircularLinkedList l = new CircularLinkedList();
        int[] list_expected = {1,2,3};
        for (int i: list_expected ) {
        	l.addLast(i);
        }
        
        int[] list_expected_reversed = {3,2,1};
        ListNode node = l.getTail();
        for (int expected: list_expected_reversed  ) {
        	int actual = node.getData();
        	assertEquals(expected, actual);
        	node = node.getPrevious();
        }       
    }
	
	@Test(timeout = 5000)
    public void testReverse()
    {
		CircularLinkedList l = new CircularLinkedList();
        int[] list_expected = {1,2,3};
        for (int i: list_expected ) {
        	l.addLast(i);
        }
        
        l.reverse();
        int[] list_expected_reversed = {3,2,1};
        ListNode node = l.getTail();
        for (Integer expected: list_expected_reversed  ) {
        	Integer actual = node.getData();
        	assertEquals(expected, actual);
        	node = node.getPrevious();
        }       
    }
	
	@Test(timeout = 5000)
	public void testIsOrderedFalseAscendingTrue() 
	{
		CircularLinkedList l = new CircularLinkedList();
		int[] list_ordered_false = {2,1,3};
		for (int i: list_ordered_false ) {
        	l.addLast(i);
        }
		boolean expected = false;
		boolean ascending = true;
		boolean actual = l.isOrdered(ascending);
		assertEquals(expected, actual);
	}
	

	@Test(timeout = 5000)
	public void testIsOrderedFalseAscendingFalse() 
	{
		CircularLinkedList l = new CircularLinkedList();
		int[] list_ordered_false = {2,1,3};
        for (int i: list_ordered_false ) {
        	l.addLast(i);
        }
		boolean expected = false;
		boolean ascending = false;
		boolean actual = l.isOrdered(ascending);
		assertEquals(expected, actual);
	}
	
	@Test(timeout = 5000)
	public void testIsOrderedTrueAscendingFalse() 
	{
		CircularLinkedList l = new CircularLinkedList();
		int[] list_ordered_false = {3,2,1};
        for (int i: list_ordered_false ) {
        	l.addLast(i);
        }
		boolean expected = true;
		boolean ascending = false;
		boolean actual = l.isOrdered(ascending);
		assertEquals(expected, actual);
	}
	
	@Test(timeout = 5000)
	public void testIsOrderedTrueAscendingTrue() 
	{
		CircularLinkedList l = new CircularLinkedList();
		int[] list_ordered_false = {1,2, 3};
        for (int i: list_ordered_false ) {
        	l.addLast(i);
        }
		boolean expected = true;
		boolean ascending = true;
		boolean actual = l.isOrdered(ascending);
		assertEquals(expected, actual);
	}
	
	@Test(timeout = 5000)
	public void testIsOrderedEmptyAscendingTrue()
	{
		CircularLinkedList l = new CircularLinkedList();
		
		boolean expected = true;
		boolean ascending = true;
		boolean actual = l.isOrdered(ascending);
		assertEquals(expected, actual);
	}
	
	@Test(timeout = 5000)
	public void deleteBeforeEmpty() {
		CircularLinkedList l = new CircularLinkedList();
		int[] listBeforeDelete = {1};
        for (int i: listBeforeDelete ) {
        	l.addLast(i);
        }
        ListNode nodeDelete = l.search(1);
        assertTrue(nodeDelete != null);
        l.delete(nodeDelete);
        assertTrue(l.isEmpty());

        
	}
	
	@Test(timeout = 5000)
	public void deleteFirstElement() {
		CircularLinkedList l = new CircularLinkedList();
		int[] listBeforeDelete = {1,2,3};
        for (int i: listBeforeDelete ) {
        	l.addLast(i);
        }
        ListNode nodeDelete = l.search(1);
        int[] listAfterDelete = {3,2};
        l.delete(nodeDelete);
        ListNode node = l.getTail();
        for (int expected: listAfterDelete  ) {
        	int actual = node.getData();
        	assertEquals(expected, actual);
        	node = node.getPrevious();
        }      
	}
	
	@Test(timeout = 5000)
	public void deleteLastElement() {
		CircularLinkedList l = new CircularLinkedList();
		int[] listBeforeDelete = {1,2,3};
        for (int i: listBeforeDelete ) {
        	l.addLast(i);
        }
        ListNode nodeDelete = l.search(3);
        int[] listAfterDelete = {2,1};
        l.delete(nodeDelete);
        ListNode node = l.getTail();
        for (int expected: listAfterDelete  ) {
        	int actual = node.getData();
        	assertEquals(expected, actual);
        	node = node.getPrevious();
        }      
	}
	
	@Test(timeout = 5000)
	public void deleteMiddleElement() {
		CircularLinkedList l = new CircularLinkedList();
		int[] listBeforeDelete = {1,2,3};
        for (int i: listBeforeDelete ) {
        	l.addLast(i);
        }
        ListNode nodeDelete = l.search(2);
        int[] listAfterDelete = {3,1};
        l.delete(nodeDelete);
        ListNode node = l.getTail();
        for (int expected: listAfterDelete  ) {
        	int actual = node.getData();
        	assertEquals(expected, actual);
        	node = node.getPrevious();
        }       
        
	}

}
