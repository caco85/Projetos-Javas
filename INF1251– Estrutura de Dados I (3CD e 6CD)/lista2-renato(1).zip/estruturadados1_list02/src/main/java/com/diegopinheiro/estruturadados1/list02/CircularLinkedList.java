package com.diegopinheiro.estruturadados1.list02;


public class CircularLinkedList {
	
	private int size;
	private ListNode sentinel;
	
	public CircularLinkedList() {
		this.size = 0;
		this.sentinel = new ListNode(0);
		this.sentinel.setNext(sentinel);
		this.sentinel.setPrevious(sentinel);
		
	}
	
	
	public ListNode getHead() {
		return sentinel.getNext();
	}


	public void setHead(ListNode head) {
		this.sentinel.setNext(head);
	}


	public ListNode getTail() {
		return sentinel.getPrevious();
	}


	public void setTail(ListNode tail) {
		this.sentinel.setPrevious(tail);
	}


	public int getSize() {
		return size;
	}


	public void setSize(int size) {
		this.size = size;
	}


	public boolean isEmpty() {
		return size == 0;
	}
	public void addFirst(int i) {
		ListNode newNode = new ListNode(i,sentinel,sentinel.getNext());
		sentinel.getNext().setPrevious(newNode);
		sentinel.setNext(newNode);
		size = size+1;
	}


	public void addLast(int i) {
		ListNode newNode = new ListNode(i,sentinel,sentinel.getPrevious());
		sentinel.getPrevious().setNext(newNode);
		sentinel.setPrevious(newNode);
		size = size+1;
	}


	public void reverse() {
		// TODO Auto-generated method stub
		
	}


	public boolean isOrdered(boolean ascending) {
		for(int i = 0 ; i < this.size ;i = i+1) {
			if (ascending == true && i > i+ 1) {
				return true;
			}
			else if (ascending == true && i < i+ 1) {
				return true;
			}
			if (ascending == false && i > i+ 1) {
				return true;
			}
			else if (ascending == false && i < i+ 1) {
				return false;
			}
			
		} 
		
		return false;
	}


	public ListNode search(int i) {
		// TODO Auto-generated method stub
		return null;
	}


	public void delete(ListNode nodeDelete) {
		// TODO Auto-generated method stub
		
	}

}
