package com.diegopinheiro.estruturadados1.list02;


public class ListNode {
		
	private int data;
	private ListNode next;
	private ListNode previous;
	
	
	public ListNode(int data) {
		this.data = data;
	}

	public ListNode(int data,ListNode next,ListNode prev) {
		this.data = data;
		this.next = next;
		this.previous = prev;
	}

	public int getData() {
		
		return this.data;
	}

	

	public void setData(int data) {
		this.data = data;
	}

	public ListNode getNext() {
		return next;
	}

	public void setNext(ListNode next) {
		this.next = next;
	}

	public ListNode getPrevious() {
		return previous;
	}

	public void setPrevious(ListNode previous) {
		this.previous = previous;
	}
	
	@Override
	public boolean equals(Object obj) {
		ListNode otherListNode = (ListNode) obj;
		return this.getData() == otherListNode.getData();
	}

	
}
