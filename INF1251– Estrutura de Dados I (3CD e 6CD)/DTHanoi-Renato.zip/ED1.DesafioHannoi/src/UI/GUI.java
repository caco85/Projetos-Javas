package UI;

import java.util.Scanner;
import java.util.Stack;


public class GUI {
	public static Scanner scanner = new Scanner(System.in);
	private static Stack<String> pilha = new Stack<String>();
	private static long qtdMove;
	
	public static void main(String[] qtdDisc) {
		
		Stack<Integer> A = new Stack<>();
		Stack<Integer> B = new Stack<>();
		Stack<Integer> C = new Stack<>();
		int qtdDisco,i,opcTH;
		
		System.out.print("Digite a quantide de disco para sua torre de Hanoi: ");
		qtdDisco = scanner.nextInt();
		
		System.out.print("Digite a op��o da torre 1-recursiva 2-interativa: ");
		opcTH = scanner.nextInt();
		if (opcTH == 1) {
			
			for (i = 1; i <= qtdDisco; i++) {
				A.push(i);		
			}
			
			torreHanoiRec(qtdDisco, A, B, C);
		} else {
			torreHanoi(qtdDisco);
		}
	
	}
	
	public static void torreHanoiRec(int qtd,Stack<Integer> A,Stack<Integer> B,Stack<Integer> C) {
		
		if(qtd > 0) {
			torreHanoiRec(qtd-1, A, C, B);
			B.push(A.pop());
			System.out.println("---Disco---");
			System.out.println("A" + A);
			System.out.println("B" + B);
			System.out.println("C" + C);
			torreHanoiRec(qtd-1, C, B, A);
			
		}
	}
	
	private static void move(int O, int D) {
		qtdMove++;
		System.out.println("[" + qtdMove + "]:" + O + " -> " + D);
	}
	
	public static void torreHanoi(int qtd) {
		int O = 1; 
		int D = 3; 
		int T = 2; 
		
		String current = qtd + "," + O + "," + D + "," + T;
		pilha.push(current);

		while (!pilha.empty()) {

			if (qtd > 1) {
				qtd--;
				String[] vetAux = current.split(",");
				O = Integer.parseInt(vetAux[1]);
				D = Integer.parseInt(vetAux[2]);
				T = Integer.parseInt(vetAux[3]);

				current = qtd + "," + O + "," + T + "," + D;
				pilha.push(current);
				
			} else {

				current = pilha.pop();

				String[] vetAux = current.split(",");
				qtd = Integer.parseInt(vetAux[0]);
				O = Integer.parseInt(vetAux[1]);
				D = Integer.parseInt(vetAux[2]);
				T = Integer.parseInt(vetAux[3]);

				move(O, D);

				if (qtd > 1) {
					qtd--;
					current = qtd + "," + T + "," + D + "," + O;
					pilha.push(current);
				}

			}

		}
		
	}
}
