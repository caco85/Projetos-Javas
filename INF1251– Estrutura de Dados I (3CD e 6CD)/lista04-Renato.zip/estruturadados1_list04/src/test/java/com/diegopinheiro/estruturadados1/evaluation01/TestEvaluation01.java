// não precisei fazer esse teste....


//package com.diegopinheiro.estruturadados1.evaluation01;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertTrue;
//
//import org.junit.Assert;
//import org.junit.Test;
//
//
//public class TestEvaluation01 {
//	
//	
//	@Test
//	public void testIsReversed() {
//		CircularLinkedList list = new CircularLinkedList();
//		int[] elementsToAdd = {1,2,3};
//        for (int i: elementsToAdd ) {
//        	list.addLast(i);
//        }
//        
//        CircularLinkedList listReversed = new CircularLinkedList();
//        for (int i: elementsToAdd ) {
//        	listReversed.addFirst(i);
//        }
//        
// 
//        boolean actual = list.isReverse(listReversed);
//        boolean expected = true;
//        
//        Assert.assertEquals(expected, actual);
//        
//	}
//	
//
//	@Test
//	public void testIsReversedReverse() {
//		CircularLinkedList list = new CircularLinkedList();
//		int[] elementsToAdd = {1,2,3};
//        for (int i: elementsToAdd ) {
//        	list.addLast(i);
//        }
//        
//        CircularLinkedList listReversed = new CircularLinkedList();
//        for (int i: elementsToAdd ) {
//        	listReversed.addLast(i);
//        }
//        listReversed.reverse();
//        
//        
//        boolean actual = list.isReverse(listReversed);
//        boolean expected = true;
//        
//        Assert.assertEquals(expected, actual);
//        
//	}
//	
//	
//	@Test
//	public void testIsReversedCopyReverse() {
//		CircularLinkedList list = new CircularLinkedList();
//		int[] elementsToAdd = {1,2,3};
//        for (int i: elementsToAdd ) {
//        	list.addLast(i);
//        }
//        
//        CircularLinkedList listReversed = list.copy();
//        listReversed.reverse();
//        
//        
//        boolean actual = list.isReverse(listReversed);
//        boolean expected = true;
//        
//        Assert.assertEquals(expected, actual);
//        
//	}
//	
//	public void testEmptyTrue()
//    {
//        CircularLinkedList l = new CircularLinkedList();
//        assertTrue(l.isEmpty());
//    }
//	
//	@Test
//    public void testEmptyFalse()
//    {
//		CircularLinkedList l = new CircularLinkedList();
//        l.addFirst(0);
//        assertTrue(!l.isEmpty());
//    }
//	
//	@Test
//    public void testAddFirst()
//    {
//		CircularLinkedList l = new CircularLinkedList();
//        int[] list_expected = {1,2,3};
//        for (int i: list_expected ) {
//        	l.addFirst(i);
//        }
//        
//        ListNode node = l.getTail();
//        for (int expected: list_expected  ) {
//        	int actual = node.getData();
//        	assertEquals(expected, actual);
//        	node = node.getPrevious();
//        }      
//    }
//	
//	@Test
//    public void testAddLast()
//    {
//		CircularLinkedList l = new CircularLinkedList();
//        int[] list_expected = {1,2,3};
//        for (int i: list_expected ) {
//        	l.addLast(i);
//        }
//        
//        int[] list_expected_reversed = {3,2,1};
//        ListNode node = l.getTail();
//        for (int expected: list_expected_reversed  ) {
//        	int actual = node.getData();
//        	assertEquals(expected, actual);
//        	node = node.getPrevious();
//        }       
//    }
//	
//	@Test
//    public void testReverse()
//    {
//		CircularLinkedList l = new CircularLinkedList();
//
//        int[] listOriginal = {1,2,3};
//        for (int i: listOriginal ) {
//        	l.addLast(i);
//        }
//        
//        l.reverse();
//        int[] listReversed = {3,2,1};
//        ListNode nodeHead = l.getHead();
//        ListNode nodeTail = l.getTail();
//        
//        int i = 0;
//        int size = l.size();
//        if(size != 3) {
//        	Assert.fail();
//        }
//        while (i < size) {
//        	int actualHead = nodeHead.getData();
//        	Assert.assertEquals(listReversed[i], actualHead);
//        	int actualTail = nodeTail.getData();
//        	assertEquals(listOriginal[i], actualTail);
//        	nodeHead = nodeHead.getNext();
//        	nodeTail = nodeTail.getPrevious();
//        	i ++;
//        }     
//
//    }
//	
//	@Test
//    public void testCopyEmpty()
//    {
//		CircularLinkedList listOriginal = new CircularLinkedList();
//		
//        CircularLinkedList listCopy = listOriginal.copy();
//        Assert.assertFalse(listOriginal == listCopy);
//        Assert.assertTrue(listCopy.isEmpty());
//    }
//	
//	
//	@Test
//    public void testCopyNotEmpty()
//    {
//		CircularLinkedList listOriginal = new CircularLinkedList();
//		int[] list_elements = {1,2,3};
//        for (int i: list_elements ) {
//        	listOriginal.addLast(i);
//        }
//        CircularLinkedList listCopy = listOriginal.copy();
//        Assert.assertTrue(listOriginal != listCopy);
//        ListNode nodeOriginal = listOriginal.getHead();
//        ListNode nodeCopy = listCopy.getHead();
//        int i =0;
//        int size = listOriginal.size();
//        while (i < size) {
//        	Assert.assertEquals(nodeOriginal.getData(), nodeCopy.getData());
//        	nodeOriginal = nodeOriginal.getNext();
//        	nodeCopy = nodeCopy.getNext();
//        	i++;
//        } 
//    }
//	
//	
//
//}
