package com.diegopinheiro.estruturadados1.list04;

public class StackSinglyLinkedList<T extends Item> implements IStack<T> {

	private SinglyLinkedList<T> list;	
	
	public StackSinglyLinkedList() {
		this.list = new SinglyLinkedList<T>();
	}

	@Override
	public boolean isEmpty() {
		return this.list.isEmpty();
	}

	@Override
	public void push(T item) {
		this.list.addFirst(item);
	}

	@Override
	public T pop() throws Exception {
		
		if(isEmpty()) {
			
			throw new Exception();
		}
		SinglyListNode<T> head = this.list.getHead();
		this.list.delete(head);
		return head.getItem();
	}



}
