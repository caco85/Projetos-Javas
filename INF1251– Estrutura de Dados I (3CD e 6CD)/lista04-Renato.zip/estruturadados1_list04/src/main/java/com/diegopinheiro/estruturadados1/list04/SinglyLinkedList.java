package com.diegopinheiro.estruturadados1.list04;

public class SinglyLinkedList<T extends Item>  {
	
	private SinglyListNode<T> head;
	
	
	public SinglyLinkedList() {
		this.head = null;
	
		
	}
	public boolean isEmpty() {
		return this.head == null;
	}

		
	public SinglyListNode<T> getHead() {
		return head;
	}
	public void setHead(SinglyListNode<T> head) {
		this.head = head;
	}
	
	
	public void addFirst(T item) {
		SinglyListNode<T> oldHead =this.head;
		SinglyListNode<T> newHead = new SinglyListNode<T>(item,oldHead);
		this.head= newHead;
		
	}
	
	public void addLast(T item){
		SinglyListNode<T> newTail = new SinglyListNode<T>(item,null);
		if(this.isEmpty()) {
			this.head = newTail;
			return;
		}
		SinglyListNode<T> oldTail = new SinglyListNode<T>(item,this.head);
		while(oldTail.getNext() != null) {
			oldTail = oldTail.getNext();
		}
		oldTail.setNext(newTail);
	}
	
	public void delete(SinglyListNode<T> nodeDelete) {
		SinglyListNode<T> node = this.head;
		if(node == nodeDelete) {
			this.head = this.head.getNext();
		}
		
		else {
			
			while(node != null) {
				if(node.getNext().getItem() == nodeDelete.getItem()) {
					node.setNext(nodeDelete.getNext());
					break;
				}
				node = node.getNext();
			}
		}
	}

}
