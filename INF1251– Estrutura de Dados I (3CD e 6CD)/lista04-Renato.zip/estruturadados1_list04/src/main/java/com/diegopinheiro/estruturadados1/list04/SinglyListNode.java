package com.diegopinheiro.estruturadados1.list04;

public class SinglyListNode<T> {
	
	private T item;
	private SinglyListNode<T> next;

	public SinglyListNode(T item,SinglyListNode<T> next) {
		this.item = item;
		this.next = next;
	}

	public T getItem() {
		
		return this.item;
	}

	public SinglyListNode<T> getNext() {
		return next;
	}
	

	public void setNext(SinglyListNode<T> next) {
		this.next = next;
	}

	


	@Override
	public boolean equals(Object obj) {
		SinglyListNode<T> otherListNode = (SinglyListNode<T>) obj;
		return this.getItem() == otherListNode.getItem();
	}

	
}
