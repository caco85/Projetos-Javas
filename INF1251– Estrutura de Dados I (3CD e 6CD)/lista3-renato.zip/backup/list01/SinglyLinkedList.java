package com.diegopinheiro.estruturadados1.list01;

public class SinglyLinkedList {
	
	private ListNode head;
	private ListNode tail;
	private int size;
	
	public SinglyLinkedList() {
		this.head = null;
		this.tail = null;
		this.size = 0;
		
	}
	public boolean isEmpty() {
		if(size == 0) {
			return true;
		}else {
			return false;
		}
		
	}

	public void addFirst(int i) {
		ListNode newHead;
		newHead = new ListNode(i,this.head);
		this.head= newHead;
		
	
		size = size+1 ;
	}
	public void addLast(int i) {
		ListNode newNode = new ListNode(i,this.head);
		if(isEmpty()) {
			this.head = newNode;
			this.tail = newNode;
		}else {
			this.tail.setNext(newNode);
			this.tail = newNode;
		}
		
		size = size+1 ;
	
	}

	public ListNode getHead() {
		return head;
	}
	public void setHead(ListNode head) {
		this.head = head;
	}
	public ListNode getTail() {
		return tail;
	}
	public void setTail(ListNode tail) {
		this.tail = tail;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	
	public ListNode search(int i) {
		ListNode a = this.head;
	
		while(a != null) {
			if(a.getElem() == i) 
				return a;
			a = a.getNext();
		}
		
		return null;
	}

	public int size() {
		return this.size;
	}

	public void reverse() {
		if(this.isEmpty()) {
			return ;
		}
		
		ListNode a = this.head.getNext();
		ListNode b = this.head;
		
		while(a != null) {
			ListNode temp = a.getNext();
			a.setNext(b);
			b=a;
			a=temp;	
		}
		this.head.setNext(null);
		this.head = b;
		
	}

	public boolean isOrdered(boolean ascending) {
		boolean descending = !ascending;
		for(int i = 0 ; i < this.size ;i = i+1) {
			if (ascending && i > i+ 1) {
				return false;
			}
			else if (ascending && i > i+ 1) {
				return true;
			}
			if (descending && i < i+ 1) {
				return false;
			}
			if (descending && i < i+ 1) {
				return true;
			}

			if (ascending && i < i+ 1) {
				return true;
			}
			if (ascending && i < i+ 1) {
				return false;
			}	
		} 
		return true;
	}

	public void delete(ListNode nodeDelete) {
		ListNode node = this.head;
		if(node == nodeDelete) {
			this.head = this.head.getNext();
		}
		
		else {
			
			while(node != null) {
				if(node.getNext().getElem() == nodeDelete.getData()) {
					node.setNext(nodeDelete.getNext());
					size = size -1;
					break;
				}
				node = node.getNext();
			}
		}
	}

}
