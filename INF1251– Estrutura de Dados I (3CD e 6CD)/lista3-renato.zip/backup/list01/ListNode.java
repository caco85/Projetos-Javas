package com.diegopinheiro.estruturadados1.list01;

public class ListNode {
		
	private int elem;
	private ListNode next;
	
	public ListNode(int elem,ListNode next) {
		this.elem = elem;
		this.next = next;
	}

	public int getData() {
		
		return this.elem;
	}

	public int getElem() {
		return elem;
	}

	public void setElem(int elem) {
		this.elem = elem;
	}

	public ListNode getNext() {
		return next;
	}

	public void setNext(ListNode next) {
		this.next = next;
	}

	@Override
	public boolean equals(Object obj) {
		ListNode otherListNode = (ListNode) obj;
		return this.getData() == otherListNode.getData();
	}

	
}
