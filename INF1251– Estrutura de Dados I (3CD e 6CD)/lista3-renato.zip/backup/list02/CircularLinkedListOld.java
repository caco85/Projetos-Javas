package com.diegopinheiro.estruturadados1.list02;

public class CircularLinkedListOld {
	
	ListNodeC sentinel;
	private int size;
	
	public CircularLinkedListOld() {
		this.size = 0;
		//sentinel = new ListNode(0 ,this.sentinel,this.sentinel.getNext());
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public ListNodeC getHead() {
		return sentinel.getNext();
	}

	public void setHead(ListNodeC sentinel) {
		this.sentinel = sentinel;
	}

	public ListNodeC getTail() {
		return sentinel.getPrevious();
	}

	public void setTail(ListNodeC sentinel) {
		this.sentinel = sentinel;
	}

	public void reverse() {
		
	}

	public boolean isEmpty() {
		return this.sentinel.getNext() == this.sentinel ;
	}

	public void addFirst(int i) {
		ListNodeC newNode = new ListNodeC(i ,this.sentinel,this.sentinel.getNext());
	    this.sentinel.getNext().setPrevious(newNode);
		this.sentinel.setNext(newNode);
		size = size +1;
	}

	public void addLast(int i) {
		
	}

	public int size() {
		return this.size;
	}

	public boolean isOrdered(boolean ascending) {
		return false;
	}

	public ListNodeC search(int i) {
		  ListNodeC node = this.sentinel;
			
			while(node != null) {
				if(node.getData() == i) {
					return node;
					
				}
				node = node.getNext();
			}
			return null;
	}

	public void delete(ListNodeC nodeDelete) {
		
	}

	public boolean isEquals(CircularLinkedListOld l2) {
		return false;
	}

	public CircularLinkedListOld copy() {
		return null;
	}

	public void get(int i) {
		
	}

}
