package com.diegopinheiro.estruturadados1.list02;

public class ListNodeC {
			
	private int data;
	private ListNodeC next;
	private ListNodeC previous;
	
	

	public ListNodeC(int data,ListNodeC next,ListNodeC prev) {
		this.data = data;
		this.next = next;
		this.previous = prev;
	}

	public int getData() {
		
		return this.data;
	}

	

	public void setData(int data) {
		this.data = data;
	}

	public ListNodeC getNext() {
		return next;
	}

	public void setNext(ListNodeC next) {
		this.next = next;
	}

	public ListNodeC getPrevious() {
		return previous;
	}

	public void setPrevious(ListNodeC previous) {
		this.previous = previous;
	}
	
	@Override
	public boolean equals(Object obj) {
		ListNodeC otherListNode = (ListNodeC) obj;
		return this.getData() == otherListNode.getData();
	}




}
