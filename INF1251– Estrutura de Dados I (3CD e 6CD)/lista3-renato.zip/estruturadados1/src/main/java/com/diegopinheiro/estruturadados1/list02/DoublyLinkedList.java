package com.diegopinheiro.estruturadados1.list02;



public class DoublyLinkedList {
	
	private ListNode head;
	private ListNode tail;
	private int size;
	
	public DoublyLinkedList() {
		this.head = null;
		this.tail = null;
		this.size = 0;
		
	}
	
	
	public ListNode getHead() {
		return head;
	}


	public void setHead(ListNode head) {
		this.head = head;
	}


	public ListNode getTail() {
		return tail;
	}


	public void setTail(ListNode tail) {
		this.tail = tail;
	}


	public int getSize() {
		return size;
	}


	public void setSize(int size) {
		this.size = size;
	}


	public boolean isEmpty() {
		return head == null;
	}
	public void addFirst(int elem) {
		ListNode newNode = new ListNode(elem ,null,this.head);
		if(isEmpty()) {
			this.head = newNode;
			this.tail = newNode;
		}else {
			newNode.setNext(this.head);
			this.head.setPrevious(newNode);
			this.head = newNode;
		}
		
		size = size+1 ;
		
	}



	

	public void addLast(int elem) {
		ListNode newNode = new ListNode(elem ,null,this.tail);
		if(isEmpty()) {
			this.head = newNode;
			this.tail = newNode;
		}else {
			this.tail.setNext(newNode);
			this.tail = newNode;
		}
		
		size = size+1 ;
		
	}


	public int size() {
		return this.size;
	}


	public void reverse() {
		if(this.isEmpty()) {
			return ;
		}
		
		ListNode a = this.head.getNext();
		ListNode b = this.head;
		
		while(a != null) {
			ListNode temp = a.getNext();
			a.setNext(b);
			b=a;
			a=temp;	
		}
		this.head.setNext(null);
		this.head = b;
		
	}


	public boolean isOrdered(boolean ascending) {
	
		for(int i = 0 ; i < this.size ;i = i+1) {
			if (ascending == true && i > i+ 1) {
				return true;
			}
			else if (ascending == true && i < i+ 1) {
				return true;
			}
			else if (ascending == true && i < i+ 1) {
				return false;
			}
			if (ascending == true && i > i+ 1) {
				return false;
			}
			if (ascending == false && i > i+ 1) {
				return true;
			}
			else if (ascending == false && i < i+ 1) {
				return false;
			}
		} 
		
		return false;
	}


	


	public boolean isPalindrome(DoublyLinkedList l) {
		int i;
		for(i = 0;i < l.getSize()/2;i= i+1)
		{
			if(l.getHead().getData() == l.getTail().getData())
			{
			l.setHead(l.getHead().getNext());
			l.setTail(l.getTail().getPrevious());
			}
			else
			{
				return false;
			}
		}

		return true;
	}
	
	public ListNode search(int i) {
		ListNode node = this.head;
		
		while(node != null) {
			if(node.getData() == i) {
				return node;
				
			}
			node = node.getNext();
		}
		return null;
	}
	
	public void delete(ListNode nodeDelete) {
		
		if(nodeDelete.getPrevious() != null) {
			nodeDelete.getPrevious().setNext(nodeDelete.getNext());
			size =size -1;
		}
		else {
			this.head =nodeDelete.getNext();
			size =size -1;
		}
		if((nodeDelete.getNext() != null)) {
			nodeDelete.getNext().setPrevious(nodeDelete.getPrevious());
			size =size -1;
		}else {
			this.tail =nodeDelete.getPrevious();
			size =size -1;
		}
	}

	public void delete2(int elem) {
		ListNode node = search(elem);
		
		if(node == null) {
			System.out.println("node not found");
		}
		else {
			while(node != null) {
				delete(node);
				node = search(elem);
			}
		}	
	}

}
	//public void delete1(int elem) {
		
	//	ListNode node = this.head;		
		
	//	while(node != null) {
	//		if(node != null && node.getData() == elem) {
	//			this.head = node.getNext();	
	//		}
	//		else if(node != null && node.getData() !=elem) {
	//			head.setPrevious(node);
	//			node = node.getNext();
	//		}
	//		
	//		head.getPrevious().setNext(node.getNext());
	//
	 	

