package com.diegopinheiro.estruturadados1.list03;


public class CircularLinkedList {
	
	ListNode sentinel;
	private int size;
	
	
	public CircularLinkedList() {
		this.size = 0;
		this.sentinel = new ListNode(-1);
	    this.sentinel.setNext(sentinel);
	    this.sentinel.setPrevious(sentinel);
	}

	
	public ListNode getSentinel() {
		return sentinel;
	}


	public void setSentinel(ListNode sentinel) {
		this.sentinel = sentinel;
	}


	public int getSize() {
		return size;
	}


	public void setSize(int size) {
		this.size = size;
	}


	public ListNode getHead() {
		return this.sentinel.getNext();
	}
	
	public ListNode getTail() {
		return this.sentinel.getPrevious();
	}
	
	
	public boolean isEmpty() {
		return this.sentinel.getNext() == this.sentinel ;
	}

	public void addFirst(int i) {
		ListNode newNode = new ListNode(i ,this.sentinel.getNext(),this.sentinel);
	    this.sentinel.getNext().setPrevious(newNode);
		this.sentinel.setNext(newNode);
		size = size +1;
	}

	public void addLast(int i) {
		ListNode newNode = new ListNode(i ,this.sentinel,this.sentinel.getPrevious());
	    this.sentinel.getPrevious().setNext(newNode);
		this.sentinel.setPrevious(newNode);
		size = size +1;
	}

	public void reverse() {
		ListNode a = this.sentinel;
		ListNode b = this.sentinel.getPrevious();
		ListNode temp = sentinel.getNext();
		while(temp != null) {
			
			a.setNext(temp.getNext());
			temp.setNext(b.getPrevious());;
			b.setPrevious(temp);	
			temp= temp.getNext();
		}
		b = sentinel.getPrevious();
		a.setNext(sentinel.getNext()); 
		
	}

	public int size() {
		return this.size;
	}

	public boolean isOrdered(boolean ascending) {
		
		if(isEmpty()) {
			return true;
		}
		while(sentinel.getNext() != null) {
			
			if(sentinel.getPrevious().getData() > sentinel.getNext().getData()) {
				return false;
			}
			
			if(sentinel.getPrevious().getData() < sentinel.getNext().getData()) {
				return false;
			}
			 sentinel.setPrevious(sentinel.getNext());
			 sentinel.setNext(sentinel.getNext());
		}
		
		return true;
	}

	public ListNode search(int i) {
		ListNode node = this.sentinel;
		if(isEmpty()) {
			return null;
		}
		
		while(node != null) {
			if(node.getData() == i) {
				return node;
				
			}
			node = node.getNext();
		}
		return null;
	}

	public void delete(ListNode nodeDelete) {
		if(nodeDelete.getPrevious() != null) {
			nodeDelete.getPrevious().setNext(nodeDelete.getNext());
			size =size -1;
		}
		else {
			this.sentinel.setNext(nodeDelete.getNext());
			size =size -1;
		}
		if((nodeDelete.getNext() != null)) {
			nodeDelete.getNext().setPrevious(nodeDelete.getPrevious());
			size =size -1;
		}else {
			this.sentinel.setPrevious(nodeDelete.getPrevious());
			size =size -1;
		}
		
	}
	public int get(int i) {
	    if (isEmpty()) {
	        return i;
	      } 
	      ListNode node = sentinel;
	      while (i > 0) {
	       node = node.getNext();
	        i = i-1;
	      }
	      return node.getData();
	}

	public boolean isEquals(CircularLinkedList l2) {
		CircularLinkedList otherCLL = new CircularLinkedList();
		ListNode node = sentinel;
		if(!isEmpty()) {
			for (int i = 0 ; i < l2.size();i= i+1) {
				otherCLL.addLast(node.getData());
				node = node.getNext();
				
			}			
		}
		if(!otherCLL.equals(l2))
		{
			return false;
		}
		return true;
	}

	public CircularLinkedList copy() {
		CircularLinkedList listCopy = new CircularLinkedList();
		ListNode node = sentinel.getNext();
		if(!isEmpty()) {
			for (int i = 0 ; i < size; i= i+1) {
				listCopy.addLast(node.getData());
				node = node.getNext();
				
			}			
		}
	
		return listCopy;
	}
	
}

	




