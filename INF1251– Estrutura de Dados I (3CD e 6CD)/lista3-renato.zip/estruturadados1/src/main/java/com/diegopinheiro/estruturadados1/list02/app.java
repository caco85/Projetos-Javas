package com.diegopinheiro.estruturadados1.list02;

public class app {
	public static void main(String[] args) {

		DoublyLinkedList l = new DoublyLinkedList();
        int[] list_expected = {1,2,3,3,3,5};
        for (int i: list_expected ) {
        	l.addFirst(i);
        } 
        l.delete2(3);
        
        for(int i=0 ;i< list_expected.length;i++) {
        	System.out.println(i);
    		
    	}
	}
	
	
}
